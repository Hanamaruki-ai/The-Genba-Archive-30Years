## **📂 Primary Source / 一次資料について**

**English:** This folder contains the "Primary Source Logs" that form the absolute foundation of this educational package. These are not mere technical documents; they are a dense record of 30 years of frontline experience, capturing the structural erosion of Japanese manufacturing and the "leeway-free" reality of modern workplaces.

These logs serve as the "ground truth" for the AI (NotebookLM) to understand the deep context behind the human-AI gap. By feeding these original records into the system, you can extract insights that go far beyond surface-level theory.

**Key Contents:**

* Raw dialogue logs analyzing "Human Erosion."  
* Structural exposes of labor shortages in Japanese factories.  
* The reality of AI implementation in highly optimized environments.

---

**日本語：** このフォルダには、本教材パッケージの絶対的な土台となる「一次資料（対話ログ）」が格納されています。これらは単なる技術資料ではありません。現場で30年間培われた経験に基づき、日本製造業の構造的摩耗と、現代の現場から「余裕（バッファ）」が失われた真実を記録した濃密なログです。

これらの資料は、AI（NotebookLM）が「人間とAIの溝」の深い文脈を理解するための「正解データ（Ground Truth）」として機能します。このオリジナル記録を読み込ませることで、表面的な理論を遥かに凌駕する深い洞察を引き出すことが可能になります。

**主な内容：**

* 「人材空洞化」を解剖した生の実録ログ  
* 日本の工場における人手不足の構造的暴露  
* 最適化され尽くした現場におけるAI導入の真実

## **一次資料リスト（日本語名）**

1. **AIエ－ジェント人材空洞化　0122-01 .md**  
2. **日本製造業の人手不足構造暴露 grok.logs 0125.md**  
3. **AIエージェント人材空洞化02 0123.md**  
4. **AIエージェント人材空洞化03 0125.md**  
5. **AIｘ人材空洞化 04 0126-01.md**  
6. **AIｘ人材空洞化 05 0126-02.md**

